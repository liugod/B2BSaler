# Trade Chat Demo

A minimal Node.js + Socket.io demo that implements the 3‑30‑3 rule for B2B inquiry handling with basic intent detection.

## Quick Start (local)

```bash
git clone <repo-url>
cd b2b_chat_demo
npm install
npm start
```

Then open http://localhost:3000 in your browser.

## Deploy on GitHub Codespaces

1. Create a new repository and push this folder's contents.
2. Click **Code → Codespaces → Create codespace**.
3. Wait for dependencies to finish installing (the `postCreateCommand` in `.devcontainer` will run `npm install`).
4. In the Codespaces toolbar, click **Ports** and make port **3000** public.
5. Click the URL that appears — your live chat demo is ready to share.

## How It Works

* `server.js` serves static files in `/public` and handles Socket.io events.
* `classifyIntent()` uses regex to map visitor messages to six intents: Urgent, Sample, Price, Specs, RFQ, Partner.
* The Bot replies with canned responses or hands over to a human agent.

## Next Steps

* Swap `classifyIntent()` for an OpenAI API call to improve accuracy.
* Persist chat sessions in Postgres and sync to your CRM.
* Integrate WhatsApp Cloud API for multichannel follow‑up.
