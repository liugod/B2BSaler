import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: "*" } });

app.use(express.static('public'));

function classifyIntent(text) {
  text = text.toLowerCase();
  if (/(urgent|asap|48h)/.test(text)) return 'Urgent';
  if (/(sample|trial)/.test(text)) return 'Sample';
  if (/(price|best price)/.test(text)) return 'Price';
  if (/(datasheet|size|material|certificate)/.test(text)) return 'Specs';
  if (/(rfq|tender|annual)/.test(text)) return 'RFQ';
  if (/(exclusive|long term)/.test(text)) return 'Partner';
  return 'General';
}

io.on('connection', (socket) => {
  console.log('visitor connected', socket.id);
  socket.emit('bot', 'Hi there! 👋 How can I help you today?');

  socket.on('visitor', (msg) => {
    const intent = classifyIntent(msg);
    socket.emit('bot', `(Detected intent: ${intent})`);

    switch (intent) {
      case 'Price':
        socket.emit('bot', 'Could you tell me your expected purchase volume so I can give you an accurate quote?');
        break;
      case 'Sample':
        socket.emit('bot', 'Sure, may I have your shipping address and courier account?');
        break;
      case 'Urgent':
        socket.emit('bot', 'I see your request is urgent. Let me connect you with a sales rep right away.');
        break;
      default:
        socket.emit('bot', 'Thanks for the details! A human agent will join shortly.');
    }
  });
});

const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, () => console.log(`Server listening on ${PORT}`));
