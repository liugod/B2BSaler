const socket = io();
const messages = document.getElementById('messages');
const input = document.getElementById('input');

function append(text, cls){
  const div = document.createElement('div');
  div.textContent = text;
  div.className = cls;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

socket.on('bot', text => append('🤖 ' + text, 'bot'));

input.addEventListener('keydown', e => {
  if(e.key === 'Enter' && input.value.trim()){
    const text = input.value.trim();
    append(text, 'visitor');
    socket.emit('visitor', text);
    input.value = '';
  }
});
